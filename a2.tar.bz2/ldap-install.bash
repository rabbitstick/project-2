#!/bin/bash
#CIT 470 Guriel
#Team 1: Sean Hasenstab, David Geis, Clay Dempsey
#CIT 470 Project Two
#LDAP Install Calls other scripts to configure Apache and generate SSL key

log="/root/ldap-install.log"
ip=$(/sbin/ip -o -4 addr list ens33 | awk '{print $4}' | cut -d/ -f1)
export log
export ip


echo "Beginning Install for LDAP..." | tee -a $log
chmod 755 install-ldap-server1.bash
chmod 755 install-ldap-server2.bash
chmod 755 install-ldap-server3.bash
./install-ldap-server1.bash
./install-ldap-server2.bash
./install-ldap-server3.bash
echo "LDAP Install finished!" | tee -a $log
echo "Beginning configuration for NFS..." | tee -a $log
chmod 755 install-nfs-server.bash
./install-nfs-server.bash
echo "NFS configuration finished" | tee -a $log

reboot
