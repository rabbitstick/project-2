#!/bin/bash
#Team 1
#CIT 470 
#Project 2
#Members: David Geis, Clay Dempsey, Sean Hasenstab

#Copy base.ldif file
	cp base.ldif /etc/httpd
	cp base.ldif /usr/share/migrationtools  >> ldap-server.log
	systemctl start slapd.service >> ldap-server.log
	systemctl restart slapd.service >> ldap-server.log		
#Add required LDAP Schemas
ldapadd -Y EXTERNAL -H ldapi:/// -f /etc/openldap/schema/core.ldif >> ldap-server.log
	ldapadd -Y EXTERNAL -H ldapi:/// -f /etc/openldap/schema/cosine.ldif >> ldap-server.log
	ldapadd -Y EXTERNAL -H ldapi:/// -f /etc/openldap/schema/nis.ldif >> ldap-server.log
	ldapadd -Y EXTERNAL -H ldapi:/// -f /etc/openldap/schema/inetorgperson.ldif >> ldap-server.log
#Restart slapd.service to enfore the changes
systemctl stop slapd.service >> ldap-server.log
	chown -R ldap:ldap /var/lib/ldap >> ldap-server.log
	#Migrate data
	slapadd -v -l /usr/share/migrationtools/base.ldif  >> ldap-server.log
	cd /usr/share/migrationtools/ >> ldap-server.log
	./migrate_passwd.pl /etc/passwd > passwd.ldif >> ldap-server.log
	slapadd -v -l passwd.ldif >> ldap-server.log
	./migrate_group.pl /etc/group > group.ldif
	slapadd -v -l group.ldif >> ldap-server.log
	chown -R ldap.ldap /var/lib/ldap >> ldap-server.log
	systemctl start slapd >> ldap-server.log