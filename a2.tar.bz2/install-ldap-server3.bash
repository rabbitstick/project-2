#!/bin/bash
#Team 1
#CIT 470 
#Project 2
#Members: David Geis, Clay Dempsey, Sean Hasenstab


#UP UNTIL THIS POINT I WAS ABLE TO START EVERYTHING FINE, AND THE USERS APPEAR TO BE ADDED CORRECTLY
	cd /usr/local/sbin >> ldap-server.log
	wget http://www.hits.at/diradm/diradm-1.3.tar.gz >> ldap-server.log
	tar zxvf diradm-1.3.tar.gz >> ldap-server.log
	sed -i '/BINDDN="cn=Admin,o=System"/c\BINDDN="cn=Manager,dc=cit470,dc=nku,dc=edu"' /usr/local/sbin/diradm-1.3/diradm.conf >> ldap-server.log
	sed -i '/USERBASE="ou=Users,ou=Accounts,o=System"/c\USERBASE="ou=People,dc=cit470,dc=nku,dc=edu"' /usr/local/sbin/diradm-1.3/diradm.conf >> ldap-server.log
	sed -i '/GROUPBASE="ou=Groups,ou=Accounts,o=System"/c\GROUPBASE="ou=Group,dc=cit470,dc=nku,dc=edu"' /usr/local/sbin/diradm-1.3/diradm.conf >> ldap-server.log
	cp /usr/local/sbin/diradm-1.3/diradm.conf /etc/ >> ldap-server.log
	#I might not need this line sed -i 'LDAPURI="ldap://localhost:389/"/c\LDAPURI="ldap://10.2.7.2:389/"' /usr/local/diradm-1.3/diradm.conf >> logfile
	systemctl start slapd.service >> ldap-server.log
	#COnfigure ACL
	echo "olcAccess: {0}to attrs=userPassword, by self write by anonymous auth by * none" >> /etc/openldap/slapd.d/cn=config/olcDatabase={2}hdb.ldif
	echo "olcAccess: {1} to * by self write by * read" >> /etc/openldap/slapd.d/cn=config/olcDatabase={2}hdb.ldif
	systemctl restart slapd.service >> ldap-server.log
	wget https://github.com/rabbitstick/cir470/raw/master/client-ks.cfg >> ldap-server.log
	cp client-ks.cfg /etc/httpd >> ldap-server.log
	reboot >> ldap-server.log
