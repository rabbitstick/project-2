#!/bin/bash
#Team 1
#CIT 470 
#Project 2
#Members: David Geis, Clay Dempsey, Sean Hasenstab

#Initiate help command option for ./install-ldap-server
if [ "$1" == "-h" ]; then echo "Usage: `basename $0` [Install LDAP Server. Script is invoked using the following command: ./install-ldap-server]" ; exit 0 ; fi
#Yum installs required
yum -y install openldap-servers openldap-clients >> ldap-server.log
# Backing up the config file
cp /etc/openldap/slapd.d/cn=config/olcDatabase={2}hdb.ldif /etc/openldap/slapd.d/cn=config/olcDatabase={2}hdb.ldif.backup >> ldap-server.log
#Configuring LDAP server
sed -i '/olcSuffix: dc=my-domain,dc=com/c\olcSuffix: dc=cit470,dc=nku,dc=edu' /etc/openldap/slapd.d/cn=config/olcDatabase={2}hdb.ldif >> ldap-server.log
sed -i '/olcRootDN: cn=Manager,dc=my-domain,dc=com/c\olcRootDN: cn=Manager,dc=cit470,dc=nku,dc=edu' /etc/openldap/slapd.d/cn=config/olcDatabase={2}hdb.ldif >> ldap-server.log
#Configuring the root password for LDAP
echo "olcRootPW: Lemontree2020" >> /etc/openldap/slapd.d/cn=config/olcDatabase={2}hdb.ldif
#Enable slapd and start it
systemctl enable slapd.service && systemctl start slapd >> ldap-server.log
systemctl enable slapd
#Set firewall rules
systemctl start firewalld.service
firewall-cmd --zone=public --add-port=389/tcp --permanent >> ldap-server.log
firewall-cmd --zone=public --add-port=389/udp --permanent >> ldap-server.log
firewall-cmd --zone=public --add-service=ldap --permanent >> ldap-server.log
firewall-cmd --zone=public --add-port=636/tcp --permanent >> ldap-server.log
firewall-cmd --zone=public --add-port=636/udp --permanent >> ldap-server.log
firewall-cmd --reload >> ldap-server.log
	#Creating DB_CONFIG file
		cp /usr/share/openldap-servers/DB_CONFIG.example /var/lib/ldap/DB_CONFIG >> ldap-server.log
	chown -R ldap:ldap /var/lib/ldap >> ldap-server.log
	yum install nss_ldap -y >> ldap-server.log
	#Installing the  migration tools
		yum install migrationtools -y >> ldap-server.log
		#Taking the backup of migration file
		cp /usr/share/migrationtools/migrate_common.ph /usr/share/migrationtools/migrate_common.ph.backup >> ldap-server.log
		#Editing migrate_common.ph file
	sed -i '/$DEFAULT_MAIL_DOMAIN = "padl.com";/c\$DEFAULT_MAIL_DOMAIN = "$HOSTNAME.hh.nku.edu";' /usr/share/migrationtools/migrate_common.ph >> ldap-server.log
	sed -i '/$DEFAULT_BASE = "dc=padl,dc=com";/c\$DEFAULT_BASE = "dc=cit470,dc=nku,dc=edu";' /usr/share/migrationtools/migrate_common.ph >> ldap-server.log